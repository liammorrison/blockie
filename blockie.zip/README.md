# blockie

> An action-packed game made only with modern JavaScript. Guide Blockie through many challenges.
